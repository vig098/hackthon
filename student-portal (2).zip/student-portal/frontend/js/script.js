// script.js

document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:3000/api/users/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        if (!response.ok) {
            throw new Error('Login failed');
        }

        const data = await response.json();
        localStorage.setItem('token', data.token);
        document.getElementById('login-container').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';

        // Fetch and display student details
        fetchStudentDetails();

    } catch (error) {
        console.error('Error:', error);
    }
});

document.getElementById('logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    document.getElementById('login-container').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';
});

async function fetchStudentDetails() {
    const token = localStorage.getItem('token');

    try {
        const response = await fetch('http://localhost:3000/api/students/details', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            throw new Error('Failed to fetch student details');
        }

        const student = await response.json();
        document.getElementById('student-details').innerText = `
            Name: ${student.name}
            ID: ${student.id}
            Email: ${student.email}
        `;

    } catch (error) {
        console.error('Error:', error);
    }
}
