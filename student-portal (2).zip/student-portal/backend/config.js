module.exports = {
    jwtSecret: 'your_jwt_secret',
    db: {
        host: 'localhost',
        user: 'root@localhost',
        password: 'Karthik@2003',
        database: 'student_portal'
    }
};
