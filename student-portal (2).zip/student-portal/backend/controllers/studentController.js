const db = require('../models/db');

exports.getStudentDetails = (req, res) => {
    const userId = req.userId;

    const query = `
        SELECT s.id, s.name, s.email, s.phone, s.address
        FROM students s
        JOIN users u ON u.id = s.user_id
        WHERE u.id = ?`;

    db.query(query, [userId], (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        if (results.length === 0) return res.status(404).send('No student details found.');

        res.status(200).send(results[0]);
    });
};

exports.getGrades = (req, res) => {
    const studentId = req.params.studentId;

    const query = 'SELECT * FROM grades WHERE student_id = ?';

    db.query(query, [studentId], (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        res.status(200).send(results);
    });
};

exports.getCourses = (req, res) => {
    const studentId = req.params.studentId;

    const query = 'SELECT * FROM courses WHERE student_id = ?';

    db.query(query, [studentId], (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        res.status(200).send(results);
    });
};

exports.getAttendance = (req, res) => {
    const studentId = req.params.studentId;

    const query = 'SELECT * FROM attendance WHERE student_id = ?';

    db.query(query, [studentId], (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        res.status(200).send(results);
    });
};

exports.getCirculars = (req, res) => {
    const query = 'SELECT * FROM circulars';

    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        res.status(200).send(results);
    });
};

exports.getEvents = (req, res) => {
    const query = 'SELECT * FROM events';

    db.query(query, (err, results) => {
        if (err) return res.status(500).send('Error on the server.');
        res.status(200).send(results);
    });
};
