// backend/middleware/authMiddleware.js

const jwt = require('jsonwebtoken');
const secret = 'your_jwt_secret'; // Use a strong secret in production

module.exports = (req, res, next) => {
    const token = req.headers['authorization'];

    if (!token) {
        return res.status(401).json({ message: 'Access denied' });
    }

    try {
        const decoded = jwt.verify(token.split(' ')[1], secret);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ message: 'Invalid token' });
    }
};
