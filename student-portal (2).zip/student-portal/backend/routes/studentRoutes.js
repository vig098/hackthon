const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const verifyToken = require('../middleware/verifyToken');

router.get('/student/details', verifyToken, studentController.getStudentDetails);
router.get('/student/:studentId/grades', verifyToken, studentController.getGrades);
router.get('/student/:studentId/courses', verifyToken, studentController.getCourses);
router.get('/student/:studentId/attendance', verifyToken, studentController.getAttendance);
router.get('/circulars', verifyToken, studentController.getCirculars);
router.get('/events', verifyToken, studentController.getEvents);

module.exports = router;
